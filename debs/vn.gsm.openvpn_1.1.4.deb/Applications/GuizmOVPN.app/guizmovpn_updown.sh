#!/bin/bash

#######################
# GuizmOVPN_updown.sh #
# Version 1.1.4       #
#######################

case "$script_type" in
   up)
     # Install push_fix (APSd)
     #if [ -f /System/Library/LaunchDaemons/com.apple.apsd.plist ] ; then
     #	/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.apsd.plist
     #/Applications/GuizmOVPN.app/tools install_dylib /System/Library/LaunchDaemons/com.apple.apsd.plist /Applications/GuizmOVPN.app/GuizmOVPN_pushfix.dylib 4.0
     #fi

     # Install push_fix (dataaccesd)
     #if [ -f /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist ] ; then
     #  /bin/launchctl unload /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist
     #  /Applications/GuizmOVPN.app/tools install_dylib /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist /Applications/GuizmOVPN.app/GuizmOVPN_pushfix.dylib 4.0
     #fi

     # Unload imagent
     #/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.imagent.plist

     # Handle DNS
     /Applications/GuizmOVPN.app/tools set_dns

     # Add infos about connection to be displayed in GUI
     /Applications/GuizmOVPN.app/tools writeprefs InfosIPAddress "$ifconfig_local"
     if [ "$ifconfig_netmask" == "" ] ; then
          /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask "255.255.255.255"
	  /Applications/GuizmOVPN.app/tools writeprefs InfosGateway "$ifconfig_remote"
     else
          /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask "$ifconfig_netmask"
	  /Applications/GuizmOVPN.app/tools writeprefs InfosGateway "$InfosGateway"
     fi
     /Applications/GuizmOVPN.app/tools writeprefs InfosTrafficRedirected "$traffic_is_redirected"

     # Start the dataaccessd
     #if [ -f /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist ] ; then
     #   /bin/launchctl load /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist
     #fi

     # Start the APSd
     #if [ -f /System/Library/LaunchDaemons/com.apple.apsd.plist ] ; then
     #   /bin/launchctl load /System/Library/LaunchDaemons/com.apple.apsd.plist
     #fi

     # Start imagent
     #/bin/launchctl load /System/Library/LaunchDaemons/com.apple.imagent.plist
     
     # Restart imagent
     killall -9 imagent

     # Restart mDNSResponder
     if [ "$Multicast" == "Y" ] ; then
	killall mDNSResponder
     fi
   ;;

   down)
     # Remove the connection infos
     /Applications/GuizmOVPN.app/tools writeprefs InfosIPAddress "" 
     /Applications/GuizmOVPN.app/tools writeprefs InfosSubnetMask ""
     /Applications/GuizmOVPN.app/tools writeprefs InfosGateway ""
     /Applications/GuizmOVPN.app/tools writeprefs InfosTrafficRedirected ""

     # Handle DNS
     /Applications/GuizmOVPN.app/tools unset_dns

     # Unload imagent
     #/bin/launchctl unload /System/Library/LaunchDaemons/com.apple.imagent.plist
 
     # Uninstall push_fix (APSd)
     #if [ -f /System/Library/LaunchDaemons/com.apple.apsd.plist ] ; then
     #   /bin/launchctl unload /System/Library/LaunchDaemons/com.apple.apsd.plist
     #   /Applications/GuizmOVPN.app/tools uninstall_dylib /System/Library/LaunchDaemons/com.apple.apsd.plist /Applications/GuizmOVPN.app/GuizmOVPN_pushfix.dylib 4.0
     #   /bin/launchctl load /System/Library/LaunchDaemons/com.apple.apsd.plist
     #fi

     # Uninstall push_fix (dataaccesd)
     #if [ -f /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist ] ; then
     #   /bin/launchctl unload /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist
     #	 /Applications/GuizmOVPN.app/tools uninstall_dylib /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist /Applications/GuizmOVPN.app/GuizmOVPN_pushfix.dylib 4.0
     #	 /bin/launchctl load /System/Library/LaunchDaemons/com.apple.dataaccess.dataaccessd.plist
     #fi

     # Start imagent
     #/bin/launchctl load /System/Library/LaunchDaemons/com.apple.imagent.plist
     
     # Restart imagent
     killall imagent
   ;;
   *) 
     echo "$0: invalid script_type $script_type" 
     env 
     exit 1 
   ;;
esac

#####
